function setup()

{

createCanvas(400, 300);

}

function draw()

{

background (220, 0, 200);

line(0, 50, 400, 300);

rectMode(CENTER);

rect(200, 150, 150, 150);

}